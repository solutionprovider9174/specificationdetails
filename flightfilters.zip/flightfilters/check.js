$(document).ready(function () {




    $(".rtn_airline_filters").change(function () {
        $(".rtn_airline_filters").each(function () {
            var checkme = $(this).val();
            // console.log(checkme);

            if ($(this).is(":checked")) {
                // console.log(checkme);
                $(".flt_rtn_header").each(function () {

                    var al_current = $(this).attr("rtn_airlines").split(',')[0];

                    // console.log($(this).attr("rtn_airlines"));
                    if (al_current == checkme) {
                        // console.log("hello");
                        $(this).parent().parent().parent().show();
                    } else {
                        $(this).parent().parent().parent().hide();
                    }


                });


            } else {

            }
        });
    });

    $(function () {
        $("#slider-range").slider({
            range: true,
            min: 0,
            max: 500,
            values: [75, 300],
            slide: function (event, ui) {
                $("#amount").val("$" + ui.values[0] + " - $" + ui.values[1]);
            }
        });
        $("#amount").val("$" + $("#slider-range").slider("values", 0) +
            " - $" + $("#slider-range").slider("values", 1));
    });
    $(function () {
        $("#slider-range-rtn").slider({
            range: true,
            min: 0,
            max: 500,
            values: [75, 300],
            slide: function (event, ui) {
                $("#amount-rtn").val("$" + ui.values[0] + " - $" + ui.values[1]);
            }
        });
        $("#amount-rtn").val("$" + $("#slider-range").slider("values", 0) +
            " - $" + $("#slider-range").slider("values", 1));
    });




});
