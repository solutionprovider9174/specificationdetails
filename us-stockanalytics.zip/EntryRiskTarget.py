# Risk is the equivalent of Stop Loss
# Target is the equivalent of take profit
# Entry is the equivalent of entry level.  Listed as % above open as a numeral below
# Lines 7-57 set up the DataFrame. Lines 59-91 is the code for the probability.
# There is probably more efficient code for this, but this code should provide a good idea of what
# I am looking for in the probability calculations. Please note that time is an important piece of the code 
import requests
import pandas as pd
import numpy as np

aapl_df = pd.read_csv("AAPL1.csv")
aapl_df['time'] = pd.to_datetime(aapl_df.time, format='%Y-%m-%d')
aapl_df = aapl_df.set_index('time')


aapl_df["Timestamp"] = aapl_df.index
NOpenToClose = aapl_df
NOpenToClose = NOpenToClose.between_time('9:31', '16:00')
NOpenToClose["Date"] = NOpenToClose["Timestamp"].dt.date
dates = NOpenToClose.Date.unique().tolist()
NDayOpen = NOpenToClose[0:0]
for i in dates:
    temp = NOpenToClose.loc[NOpenToClose.Date == i].iloc[-1]
    NDayOpen = NDayOpen.append(temp,ignore_index=False)
NDayOpen.index = NDayOpen.index.date
NDayOpen = NDayOpen [['open']]
NDayOpen.rename(columns = {'open':'N_Day_Open'}, inplace = True)
NDayClose = NOpenToClose[0:0]
for i in dates:
    temp = NOpenToClose.loc[NOpenToClose.Date == i].iloc[0]
    NDayClose = NDayClose.append(temp,ignore_index=False)
NDayClose.index = NDayClose.index.date
NDayClose = NDayClose [['close']]
NDayClose.rename(columns = {'close':'N_Day_Close'}, inplace = True)

NOpenToClose = aapl_df.between_time('9:31', '16:00')
NOpenToClose['Time']= NOpenToClose.index.time

DayN = pd.merge(NDayOpen, NDayClose, left_index = True, right_index = True)

DayN['Up_1'] = DayN['N_Day_Open'] * 1.01
DayN['Up_1.5'] = DayN['N_Day_Open'] * 1.015
DayN['Up_2.5'] = DayN['N_Day_Open'] * 1.025
DayN['Up_5'] = DayN['N_Day_Open'] * 1.05
DayN['Up_7.5'] = DayN['N_Day_Open'] * 1.075
DayN['Up_10'] = DayN['N_Day_Open'] * 1.1

DayN['Down_1'] = DayN['N_Day_Open'] * 0.99
DayN['Down_2.5'] = DayN['N_Day_Open'] * 0.985
DayN['Down_5'] = DayN['N_Day_Open'] * 0.95
DayN['Down_7.5'] = DayN['N_Day_Open'] * 0.925
DayN['Down_10'] = DayN['N_Day_Open'] * 0.9
#DayN.to_csv("DayN.csv")
RiskReward = pd.DataFrame( columns = ['Date','entry', 'entry_time', 'stop_loss' , 'stop_loss_time', 'take_profit', 'take_profit_time'])

NOpenToClose['Date'] = NOpenToClose.index.date
NOpenToClose = NOpenToClose.iloc[::-1]

for day in DayN.index:
    curData = NOpenToClose[ NOpenToClose['Date'] == day ]
    entryData = curData[ curData['high'] >= DayN['Up_1'][day]]
    if len( entryData)  == 0:
        RiskReward = RiskReward.append({'Date':day,'entry':'0','entry_time':None, 'stop_loss':'0', 'stop_loss_time':None, 'take_profit':'0', 'take_profit_time':None},ignore_index = True)
        continue
    entryTime = entryData.iloc[0]['Time']
    curData = curData[ curData['Time'] >= entryTime]
    stopData = curData[ curData['high'] >= DayN['Up_1.5'][day]]
    profitData = curData[ curData['low'] < DayN['Down_1'][day]]
    stopValue = '0' if len ( stopData) ==0  else '1'
    profitValue = '0' if len ( profitData ) == 0 else '1'
    stopTime = None
    profitTime = None
    if stopValue == '1':
        stopTime = stopData.iloc[0]['Time']
    if profitValue == '1':
        profitTime = profitData.iloc[0]['Time']
    RiskReward = RiskReward.append({'Date':day,'entry':'1','entry_time':entryTime, 'stop_loss':stopValue, 'stop_loss_time':stopTime, 'take_profit':profitValue, 'take_profit_time':profitTime},ignore_index = True)


print(RiskReward.dtypes) 
print ( RiskReward )

RiskReward.loc[
    ((RiskReward['entry'] == '1') & 
    (RiskReward['stop_loss'] != '1') &
    (RiskReward['take_profit'] == '1')) |
    ((RiskReward['entry'] == '1') & 
    (RiskReward['stop_loss'] == '1') &
    (RiskReward['take_profit'] == '1') &
    (RiskReward['take_profit_time'] < RiskReward['stop_loss_time']))
    ,'Win'] = 1